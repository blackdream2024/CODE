﻿# SenseDraw 安装说明

## 系统要求
- Windows 10/11
- Node.js 18.0 或更高版本

## 安装步骤

### 1. 安装 Node.js
如果尚未安装 Node.js，请从官网下载并安装：
https://nodejs.org/

### 2. 解压文件
将 SenseDraw-1.0.0.zip 解压到任意目录

### 3. 安装依赖
打开命令提示符，进入解压后的目录，执行：

`ash
cd backend
npm install
`

### 4. 启动程序
双击运行 start.bat 或在命令提示符中执行：

`ash
cd backend
node u1-pipeline-server.js
`

程序将在 http://localhost:3456 启动

## 使用说明
1. 启动后，在浏览器中打开 http://localhost:3456
2. 在文本框中输入系统架构描述
3. 或上传文档自动生成架构图
4. 点击"生成"按钮创建架构图

## 常见问题

### Q: 提示"端口已被占用"
A: 关闭其他占用 3456 端口的程序，或修改 backend/u1-pipeline-server.js 中的 PORT 变量

### Q: 生成失败
A: 检查网络连接，确保能访问 SenseNova API

## 技术支持
如有问题，请查看 README.md 文件
